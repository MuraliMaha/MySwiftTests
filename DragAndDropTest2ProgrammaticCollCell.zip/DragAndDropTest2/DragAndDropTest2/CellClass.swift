//
//  CollectionViewCell.swift
//  MovingCells
//
//  Created by Ozgur Vatansever on 4/24/16.
//  Copyright © 2016 Ozgur Vatansever. All rights reserved.
//

import UIKit

class CellClass: UICollectionViewCell {
    
    
  
  let imageView = UIImageView(frame: CGRect.zero)
  let cellContainer = UIView(frame:CGRect.zero)
  
  fileprivate func configureUI() {

    cellContainer.backgroundColor = UIColor.blue
    cellContainer.clipsToBounds = true
    cellContainer.contentMode = UIViewContentMode.scaleAspectFill
    cellContainer.translatesAutoresizingMaskIntoConstraints = false
    
    contentView.addSubview(cellContainer)
    
    contentView.addConstraints(NSLayoutConstraint.constraints(
          withVisualFormat: "H:|[myContainerView]|",
          options: NSLayoutFormatOptions.alignAllCenterY,
          metrics: nil,
          views: ["myContainerView": cellContainer])
        )
        contentView.addConstraints(NSLayoutConstraint.constraints(
          withVisualFormat: "V:|[myContainerView]|",
          options: NSLayoutFormatOptions.alignAllCenterX,
          metrics: nil,
          views: ["myContainerView": cellContainer])
        )
    
//    imageView.clipsToBounds = true
    imageView.layer.cornerRadius = 5.0
//    imageView.contentMode = UIViewContentMode.scaleAspectFill
    imageView.translatesAutoresizingMaskIntoConstraints = false
    
    cellContainer.addSubview(imageView)

    let ImgDict = ["Img":imageView] as [String : Any]
//    let btnleading = 0
    let imgWidth = 60 //cellContainer.frame.width/2
    let imgHeight = imgWidth
//    let btnTop = 0
    
    cellContainer.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-[Img(\(imgWidth))]-|", options: .alignAllCenterX, metrics:nil, views:ImgDict ))
    cellContainer.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-[Img(\(imgHeight))]-|", options: .alignAllCenterY, metrics: nil, views:ImgDict))
    
//    cellContainer.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|[Img]|", options: .alignAllCenterX, metrics:nil, views:ImgDict ))
//    cellContainer.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|[Img]|", options: .alignAllCenterY, metrics: nil, views:ImgDict))
    
    
//    cellContainer.addConstraints(NSLayoutConstraint.constraints(
//      withVisualFormat: "H:|[Img(\(btnWidth))]|",
//      options: NSLayoutFormatOptions.alignAllCenterX,
//      metrics: nil,
//      views: ImgDict)
//    )
//    cellContainer.addConstraints(NSLayoutConstraint.constraints(
//      withVisualFormat: "V:|[Img(\(btnHeight))]|",
//      options: NSLayoutFormatOptions.alignAllCenterY,
//      metrics: nil,
//      views: ImgDict)
//    )
    
   
    
    
    
////    cellContainer.addConstraint(NSLayoutConstraint.constraints(
//        withVisualFormat: "H:|-[Img(\(btnWidth)]",
//        options: .alignmentMask,
//        metrics: nil,
//        views: ImgDict as Any as![String : Any]))
//    cellContainer.addConstraint(NSLayoutConstraint.constraints(withVisualFormat: "V:|-[Img(\(btnheight)]", options: .alignmentMask, metrics: nil, views: ImgDict))
   
    
//    cellContainer.addConstraints(NSLayoutConstraint.constraints(withVisualFormat:"H:|[Img(\(btnWidth)]" , options: .alignmentMask, metrics: nil, views: ImgDict as Any as![String : Any]))
    
//     cellContainer.addConstraints(NSLayoutConstraint.constraints(withVisualFormat:"V:|[Img(\(btnheight)]" , options: .alignmentMask, metrics: nil, views: ImgDict as Any as![String : Any]))
    
    
  }
  
  override func snapshotView(afterScreenUpdates afterUpdates: Bool) -> UIView? {
    let snapshot = super.snapshotView(afterScreenUpdates: afterUpdates)

    snapshot?.layer.masksToBounds = false
    snapshot?.layer.shadowOffset = CGSize(width: -5.0, height: 0.0)
    snapshot?.layer.shadowRadius = 5.0
    snapshot?.layer.shadowOpacity = 0.4
    snapshot?.center = center
    
    return snapshot
  }
  
  override init(frame: CGRect) {
    super.init(frame: frame)
    configureUI()
  }
  
  required init?(coder aDecoder: NSCoder) {
    super.init(coder: aDecoder)
    configureUI()
  }
}
