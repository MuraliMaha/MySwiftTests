//
//  ViewController.swift
//  DragAndDropTest2
//
//  Created by SunTelematics on 12/03/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //   "Exclusive Access to Memory" in Building setting should be changed to "No Enforcement"
    @IBOutlet weak var myCollView: UICollectionView!
    @IBOutlet weak var myCollViewFL: UICollectionViewFlowLayout!
    
    fileprivate var snapshotView: UIView?
    fileprivate var snapshotIndexPath: IndexPath?
    fileprivate var snapshotPanPoint: CGPoint?
    
    var myImagesArray: [UIImage] = [
        UIImage(named: "Airport")!,
        UIImage(named: "test")!,
        UIImage(named: "Outstation")!,
        UIImage(named: "Package")!,
        UIImage(named: "truckImage")!,
        UIImage(named: "StarFilled")!
    ]
    
//    var imageDataSourceObj = ImageDataSource()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myCollView.dataSource = self
        myCollView.delegate = self
        
        let gestureRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(longPressRecognized(_:)))
        gestureRecognizer.minimumPressDuration = 0.2
        myCollView!.addGestureRecognizer(gestureRecognizer)
        
    }
    
    fileprivate func getTheCellForRow(at indexPath: IndexPath) -> CellClass {
        return myCollView.cellForItem(at: indexPath) as! CellClass
    }
    
    //   "Exclusive Access to Memory" in Building setting should be changed to "No Enforcement" as same array used for swapping
    func exchangeImageAtIndex(_ index: Int, withImageAtIndex otherIndex: Int) {
        if index != otherIndex {
            swap(&myImagesArray[index], &myImagesArray[otherIndex])
        }
    }
    
    @objc func longPressRecognized(_ recognizer: UILongPressGestureRecognizer) {
        let location = recognizer.location(in: myCollView)
        let indexPath = myCollView.indexPathForItem(at: location)
        
        switch recognizer.state {
        case UIGestureRecognizerState.began:
            guard let indexPath = indexPath else { return }
            
            let cell = getTheCellForRow(at: indexPath)
            snapshotView = cell.snapshotView(afterScreenUpdates: true)
            myCollView.addSubview(snapshotView!)
            cell.contentView.alpha = 0.0
            
            UIView.animate(withDuration: 0.2, animations: {
                self.snapshotView?.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
                self.snapshotView?.alpha = 0.9
            })
            
            snapshotPanPoint = location
            snapshotIndexPath = indexPath
        case UIGestureRecognizerState.changed:
            guard let snapshotPanPoint = snapshotPanPoint else { return }
            
            let translation = CGPoint(x: location.x - snapshotPanPoint.x, y: location.y - snapshotPanPoint.y)
            snapshotView?.center.x += translation.x
            snapshotView?.center.y += translation.y
            self.snapshotPanPoint = location
            
            guard let indexPath = indexPath else { return }
            
//            imageDataSourceObj.exchangeImageAtIndex(snapshotIndexPath!.item, withImageAtIndex: indexPath.item)
            exchangeImageAtIndex(snapshotIndexPath!.item, withImageAtIndex: indexPath.item)
            myCollView.moveItem(at: snapshotIndexPath!, to: indexPath)
            snapshotIndexPath = indexPath
        default:
            guard let snapshotIndexPath = snapshotIndexPath else { return }
            let cell = getTheCellForRow(at: snapshotIndexPath)
            UIView.animate(
                withDuration: 0.2,
                animations: {
                    self.snapshotView?.center = cell.center
                    self.snapshotView?.transform = CGAffineTransform.identity
                    self.snapshotView?.alpha = 1.0
            },
                completion: { finished in
                    cell.contentView.alpha = 1.0
                    self.snapshotView?.removeFromSuperview()
                    self.snapshotView = nil
            })
            self.snapshotIndexPath = nil
            self.snapshotPanPoint = nil
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
extension ViewController : UICollectionViewDelegate , UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return myImagesArray.count
//        return imageDataSourceObj.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellID", for: indexPath)
        if let cell = cell as? CellClass {
//            cell.contentView.backgroundColor = UIColor.green
            cell.imageView.image = myImagesArray[indexPath.item]
//            cell.imageView.image = imageDataSourceObj[indexPath.item]
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let totalInteritemSpacing = (1 * myCollViewFL.minimumInteritemSpacing)
        let totalSectionInset = myCollViewFL.sectionInset.left + myCollViewFL.sectionInset.right
        let w = (collectionView.bounds.width - (totalSectionInset + totalInteritemSpacing)) / 2
        
        let h = w/1.5
        
        return CGSize(width: w, height: h)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("Image selected at indexPath: \(indexPath.row)")
    }
    
}
