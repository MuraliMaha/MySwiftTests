//
//  LocationAccessVC.swift
//  NationalPermit
//
//  Created by SunTelematics on 18/08/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit

class LocationAccessVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(CallDissmiss), name: NSNotification.Name(rawValue: "LocationisEnabled"), object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "LocationisEnabled"), object: nil)
    }
    
    @objc func CallDissmiss() {
        print("Dismiss called")
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func settingsButtonTapped(_ sender: UIButton) {
        let url = URL.init(string: UIApplicationOpenSettingsURLString)!
        
        if UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.openURL(url)
        }
    }

}
