//
//  HomeVC.swift
//  LocationAccessTest1
//
//  Created by SunTelematics on 15/03/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import CoreLocation

class HomeVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        
//        let us consider that homepage requires location access.
//        let us consider that user didnt allow access in OS authorization dialog.
//        so now check authorizationStatus and if false(means authorizationStatus is false as user didnt provide access ie user selected "Dont Allow" in OS dialog),showLocationDeniedVC.
        
        if CLLocationManager.locationServicesEnabled() {
            if CLLocationManager.authorizationStatus() != .authorizedWhenInUse && CLLocationManager.authorizationStatus() != .authorizedAlways {
                showLocationDeniedVC(controller: self)
                
            }else{
                print(" Location authorizationStatus is true")
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
func showLocationDeniedVC(controller:UIViewController) -> (Void) {
    //    let locationAccessDeniedVCObj = LocationAccessView.init(nibName: "LocationAccessView", bundle: Bundle.main)
    //    let transition = CATransition()
    //    transition.duration = 0.45
    //    transition.type = kCATransitionFade
    //    transition.subtype = kCATransitionFromTop
    //    locationAccessDeniedVCObj.view.layer.add(transition, forKey: kCATransition)
    //    controller.present(locationAccessDeniedVCObj, animated: true, completion: nil)
    
    let ctrl = controller.storyboard?.instantiateViewController(withIdentifier: "LocationAccessVCSBID") as! LocationAccessVC
    //    ctrl.modalTransitionStyle = .crossDissolve
    controller.present(ctrl, animated: true, completion: nil)
    
}
