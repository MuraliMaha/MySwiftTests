//
//  ViewController.swift
//  LocationAccessTest1
//
//  Created by SunTelematics on 15/03/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import CoreLocation

class LoginVC: UIViewController {

    let locationManager = CLLocationManager()

//    You're probably being ARC'd.I was creating a CLLocationManager instance in my viewDidLoad method. Since this was a local instance to the method, the instance was released by ARC after the method completed executing. As soon as the instance was released, the dialog disappeared. The solution was rather simple. Change the CLLocationManager instance from being a method-level variable (ie. CLLocationManager().requestAlwaysAuthorization() in viewDidLoad()) to be a class-level instance variable(ie. let locationManager = CLLocationManager() as in line no.14). Now the CLLocationManager instance is only released once the class is unloaded.
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
//        CLLocationManager().requestAlwaysAuthorization()
        
//        requesting Authorization(below 2 lines) will give Operating System dialog which will ask for authorization.And in seetings of device(phone) app will be added (though location authorization permission granted/allow or not granted/Dont allow ) as we requested for authorization(below 2 lines).
        
        self.locationManager.requestAlwaysAuthorization()
        self.locationManager.requestWhenInUseAuthorization()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

