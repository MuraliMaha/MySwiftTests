//
//  RegisterVC.swift
//  Shlok
//
//  Created by SunTelematics on 04/04/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import  CoreData

class RegisterVC: UIViewController {

    @IBOutlet weak var userNameTxtFld: UITextField!
    @IBOutlet weak var passwordTxtFld: UITextField!
    
    lazy var Delegate: AppDelegate = {
        return UIApplication.shared.delegate as! AppDelegate
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func registerBtnTapped(_ sender: UIButton) {
        
        var aUserDict = [String:String]()
        aUserDict["userName"] = userNameTxtFld.text
        aUserDict["password"] = passwordTxtFld.text
        
        saveUserInEmpMaster(userDict: aUserDict)
    }
 
    func saveUserInEmpMaster(userDict: [String:String]) {
        let empMasTBObj = NSEntityDescription.insertNewObject(forEntityName: "EmpMasterTB", into: Delegate.managedObjectContext) as! EmpMasterTB
        empMasTBObj.username = "\(userDict["userName"]!)"
        empMasTBObj.password = "\(userDict["password"]!)"
        
        Delegate.saveContext()
        
        self.performSegue(withIdentifier: "toLogin", sender: nil)
    }
 
}
