//
//  HomeVC.swift
//  Shlok
//
//  Created by SunTelematics on 04/04/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import CoreData

class HomeVC: UIViewController {

    lazy var Delegate: AppDelegate = {
        return UIApplication.shared.delegate as! AppDelegate
    }()
    
    var loginTBObj : LoginTB!
    var usersArr : [EmpMasterTB]!
    
    @IBOutlet weak var testLbl: UILabel!
    @IBOutlet weak var updatePasswordTxtField: UITextField!
    @IBOutlet weak var userToDeleteTxtField: UITextField!
    
    @IBOutlet weak var myTV: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        loginTBObj = fetchLoginTB()
        self.testLbl.text = "Loged in as " + loginTBObj.username!
        
        myTV.dataSource = self
        myTV.delegate = self
        
        usersArr = fetchUsersFromEmpMasterTB()
        self.myTV.reloadData()
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func updatePasswordTapped(_ sender: UIButton) {
        if updatePasswordTxtField.text != "" {
            
            fetchEmpMasterTBAndcheckUserAndUpdatePwd(username: loginTBObj.username!, pwd: self.updatePasswordTxtField.text!)
        }
    }
    func fetchEmpMasterTBAndcheckUserAndUpdatePwd(username:String,pwd:String) {
        let context = Delegate.managedObjectContext
        
//        let entity = NSEntityDescription.entity(forEntityName: "EmpMasterTB", in: context)
//        let request = NSFetchRequest<EmpMasterTB>.init()
//        request.entity = entity
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "EmpMasterTB")
        request.predicate = NSPredicate(format: "username == %@", username)
        
        let arr = try? context.fetch(request)
        if (arr?.count)! > 0 {
            let aUserRecord = arr![0] as! EmpMasterTB
            aUserRecord.password = pwd
            Delegate.saveContext()
            print("Password updated ")
        }
    }
    
    @IBAction func deleteUserTapped(_ sender: UIButton) {
        let context = Delegate.managedObjectContext
       
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "EmpMasterTB")
        request.predicate = NSPredicate(format: "username == %@", self.userToDeleteTxtField.text!)
        
        if let managedObjArr = try? context.fetch(request) {
            context.delete(managedObjArr[0] as! NSManagedObject)
        }
        do {
            try context.save()
            print("user Deleted")
        } catch {
            print ("There was an error deleting the user, RMK")
        }
    }
    
    @IBAction func logoutTapped(_ sender: UIButton) {
        //deleting all the records in LoginTB
        let context = Delegate.managedObjectContext
        
        let deleteFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "LoginTB")
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: deleteFetch)
        
        do {
            try context.execute(deleteRequest)
            try context.save()
            self.performSegue(withIdentifier: "toLoginFromHome", sender: nil)
        } catch {
            print ("There was an error deleting the table RMK")
        }
    }
   
    func fetchLoginTB() -> LoginTB {
        let context = Delegate.managedObjectContext
        
//        let entity = NSEntityDescription.entity(forEntityName: "LoginTB", in: context)
//        let request = NSFetchRequest<LoginTB>.init()
//        request.entity = entity
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "LoginTB")
        let arr = try? context.fetch(request)
        return arr![0] as! LoginTB
    }
    func fetchUsersFromEmpMasterTB() -> [EmpMasterTB] {
        let context = Delegate.managedObjectContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "EmpMasterTB")
        let arrOfManagedObj = try? context.fetch(request)
        
        return arrOfManagedObj as! [EmpMasterTB]
    }

   
}
extension HomeVC : UITableViewDataSource , UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return usersArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellID", for: indexPath) as! CellClass
        cell.userLbl.text = usersArr[indexPath.row].username
        cell.pwdLbl.text = usersArr[indexPath.row].password
        return cell
    }
    
    
}
class CellClass : UITableViewCell{
    
    @IBOutlet weak var userLbl: UILabel!
    @IBOutlet weak var pwdLbl: UILabel!
}
