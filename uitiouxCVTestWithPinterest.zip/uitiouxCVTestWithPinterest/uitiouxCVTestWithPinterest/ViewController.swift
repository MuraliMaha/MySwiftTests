//
//  ViewController.swift
//  uitiouxCVTestWithPinterest
//
//  Created by SunTelematics on 21/12/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit
import PinterestLayout

class ViewController: PinterestVC {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        items = [
//            PinterestItem(image: UIImage(named: "new_york"), text: text),
//            PinterestItem(image: UIImage(named: "bigben_river"), text: text),
//            PinterestItem(image: UIImage(named: "dubai"), text: text),
//            PinterestItem(image: UIImage(named: "4"), text: text),
//            PinterestItem(image: UIImage(named: "tiger"), text: text)
//        ]

        items = [PinterestItem(image:UIImage(named:"car")!,text: "cartoon"),
        PinterestItem(image:UIImage(named:"lion")!,text: "Lion"),
        PinterestItem(image:UIImage(named:"leo")!,text: "Leo"),
        PinterestItem(image :UIImage(named :"elephant")!,text:"Elephant"),
        PinterestItem(image :UIImage(named :"giraffe")!,text:"giraffe"),
        PinterestItem(image :UIImage(named :"goat")!,text:"goat"),
        PinterestItem(image :UIImage(named :"tiger")!,text:"tiger"),
        PinterestItem(image :UIImage(named :"horse")!,text:"horse"),
        PinterestItem(image :UIImage(named :"year")!,text:"year"),
        PinterestItem(image :UIImage(named :"rabbit")!,text:"rabbit"),
        ]
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

