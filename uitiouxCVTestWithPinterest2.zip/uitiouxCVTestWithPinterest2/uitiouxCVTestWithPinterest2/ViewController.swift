//
//  ViewController.swift
//  uitiouxCVTestWithPinterest2
//
//  Created by SunTelematics on 21/12/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit
import PinterestLayout

class ViewController: UIViewController {

    @IBOutlet weak var myCV: UICollectionView!
    
    var myImagesArray: [UIImage] = [
        UIImage(named: "cat.jpg")!,
        UIImage(named: "horse.jpg")!,
        UIImage(named: "leo.jpg")!,
        UIImage(named: "car.jpeg")!,
        UIImage(named: "tiger.jpg")!,
        UIImage(named: "year.jpg")!,
        UIImage(named: "lion.jpg")!,
        UIImage(named: "elephant.jpeg")!,
        UIImage(named: "rabbit.jpg")!,
        UIImage(named: "goat.jpg")!
    ]
    
   var titleArr = ["Cat","Horse","Leo","Cartoon","tiger","year","lion","elephant","rabbit","Goat"]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        myCV.delegate = self
        myCV.dataSource = self
        
        let layout = PinterestLayout()
        myCV.collectionViewLayout = layout
        
        layout.delegate = self
        layout.cellPadding = 5
        layout.numberOfColumns = 2
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ViewController : UICollectionViewDelegate , UICollectionViewDataSource ,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return myImagesArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: "CollectionCell",
            for: indexPath) as! CollectionViewCell
        
        let image = myImagesArray[indexPath.item]
        
        cell.imageView.image = image
        cell.descriptionLabel.text = titleArr[indexPath.row]
        
        return cell
    }
}
extension ViewController: PinterestLayoutDelegate {
    
    func collectionView(collectionView: UICollectionView,
                        heightForImageAtIndexPath indexPath: IndexPath,
                        withWidth: CGFloat) -> CGFloat {
        let image = myImagesArray[indexPath.item]
        
        return image.height(forWidth: withWidth)
    }
    
    func collectionView(collectionView: UICollectionView,
                        heightForAnnotationAtIndexPath indexPath: IndexPath,
                        withWidth: CGFloat) -> CGFloat {
        let textFont = UIFont(name: "Arial-ItalicMT", size: 11)!
        return "Some text".heightForWidth(width: withWidth, font: textFont)
    }
}

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var imageViewHeightLayoutConstraint: NSLayoutConstraint!
    @IBOutlet weak var descriptionLabel: UILabel!
    
//    var image: UIImage? {
//        didSet {
//            if let image = image {
//                imageView.image = image
//            } else {
//                imageView.backgroundColor = .darkGray
//            }
//        }
//    }
    
    override func apply(_ layoutAttributes: UICollectionViewLayoutAttributes) {
        super.apply(layoutAttributes)
        if let attributes = layoutAttributes as? PinterestLayoutAttributes {
            //change image view height by changing its constraint
            imageViewHeightLayoutConstraint.constant = attributes.imageHeight
        }
    }
}
