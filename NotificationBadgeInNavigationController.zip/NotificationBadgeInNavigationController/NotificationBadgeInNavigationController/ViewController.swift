//
//  ViewController.swift
//  NotificationBadgeInNavigationController
//
//  Created by SunTelematics on 08/11/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let notificationCount = 112
    var label : UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //Configuring Notification Badge (No Frameworks used its just UILabel)
        
        label = UILabel(frame: CGRect(x: -16, y: -8, width: 27, height: 15))
        label.layer.borderColor = UIColor.clear.cgColor
        label.layer.borderWidth = 2
        label.layer.cornerRadius = label.bounds.size.height / 2.4
        label.textAlignment = .center
        label.layer.masksToBounds = true
        
        label.font = label.font.withSize(10)
        label.textColor = .black
        label.backgroundColor = UIColor.green
        
        //        show badge only if notification count is greater than 0
        if "\(notificationCount)" > "0" {
            label.isHidden = false
            label.text = "\(notificationCount)"
        }else{
            label.isHidden = true
        }
        
        
        // button
        let rightButton = UIButton(frame: CGRect(x: 0, y: 0, width: 30, height: 30))
        //if image size is not reduced,then the button size will enlarge to image size
        rightButton.setBackgroundImage(#imageLiteral(resourceName: "notifSymbol").ReduceImageSize(CGSize.init(width: 30, height: 30)), for: .normal)
        rightButton.addTarget(self, action: #selector(rightButtonAction), for: .touchUpInside)
        rightButton.addSubview(label)
        
        // Bar button item
        let rightBarButtomItem = UIBarButtonItem(customView: rightButton)
        
        self.navigationItem.rightBarButtonItem = rightBarButtomItem
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @objc func rightButtonAction(sender: UIBarButtonItem) {
        
//        let Track = self.storyboard?.instantiateViewController(withIdentifier: "NewOffers") as! NewOffers
//        Track.isFrom = 1
//        self.navigationController?.pushViewController(Track, animated: true)
    }


}

