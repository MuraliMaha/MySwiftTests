//
//  ViewController.swift
//  CollectionViewWithPageControlTest2
//
//  Created by SunTelematics on 08/11/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireImage

//While using page Control with CollectionView,paging should be enabled for CollectionView
class ViewController: UIViewController {

    @IBOutlet weak var offersCollectionView: UICollectionView!
    var OfferImagesarray = [[String:String]]()
    @IBOutlet weak var offersPageCtrl: UIPageControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        offersCollectionView.delegate = self
        offersCollectionView.dataSource = self
        
        let offerDict1 = ["ImageURL":"http://aamchidrivebooking.in/offers/offer4.png"]
        let offerDict2 = ["ImageURL":"http://aamchidrivebooking.in/offers/offer5.png"]
        let offerDict3 = ["ImageURL":"http://aamchidrivebooking.in/Images/Airport.png"]
        
        OfferImagesarray.append(offerDict1)
        OfferImagesarray.append(offerDict2)
        OfferImagesarray.append(offerDict3)
        
        offersPageCtrl.hidesForSinglePage = true
        offersPageCtrl.currentPage = 0
        offersPageCtrl.numberOfPages = self.OfferImagesarray.count
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
extension ViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return OfferImagesarray.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "offersCellID", for: indexPath) as! OffersCollectionViewCellClass
        
        let urlStr = URL.init(string: "\(String(describing: self.OfferImagesarray[indexPath.row]["ImageURL"]!))" )
        print("urlStr = ",urlStr!)
        
        cell.offersImgView.af_setImage(withURL: urlStr!, placeholderImage: nil, filter: nil, progress: nil, progressQueue: DispatchQueue.main, imageTransition: .noTransition, runImageTransitionIfCached: true) { (imageData) in
            if imageData.data != nil {
                cell.offersImgView.image = UIImage.init(data:imageData.data!)!
            }
        }
        
        cell.offersImgView.contentMode = .scaleAspectFit
        cell.offersImgView.clipsToBounds = true
        
        
        return cell
    }
   
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: self.offersCollectionView.frame.width, height: self.offersCollectionView.frame.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        self.offersPageCtrl.currentPage = indexPath.row
    }
    
//    func collectionView(_ collectionView: UICollectionView, didEndDisplaying cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
//        self.offersPageCtrl.currentPage = indexPath.row
//    }
}

class OffersCollectionViewCellClass : UICollectionViewCell {
    @IBOutlet weak var offersImgView: UIImageView!
}
