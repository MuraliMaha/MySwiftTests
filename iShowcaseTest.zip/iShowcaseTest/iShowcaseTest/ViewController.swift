//
//  ViewController.swift
//  iShowcaseTest
//
//  Created by SunTelematics on 16/10/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var viewOne: UIView!
    @IBOutlet weak var viewTwo: UIView!
    @IBOutlet weak var viewThree: UIView!
    @IBOutlet weak var refreshBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        ShowTripTypeShowcase()
        
//        Timer.scheduledTimer(timeInterval: 0.2, target: self, selector: #selector(LoadTitles), userInfo: nil, repeats: false)
        
        Timer.scheduledTimer(timeInterval: 0.2, target: self, selector: #selector(calliShowcase), userInfo: nil, repeats: false)
    }

    @objc func calliShowcase(){
        ShowTripTypeShowcase()
    }
    override func viewWillAppear(_ animated: Bool) {
        
    }
   
    override func viewDidAppear(_ animated: Bool) {
//        ShowTripTypeShowcase()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

extension ViewController : iShowcaseDelegate {
    func iShowcaseShown(_ showcase: iShowcase) {
        print("iShowcaseShown....." )
    }
    func iShowcaseDismissed(_ number: Int, _ showcase: iShowcase) {
        
        if number == 0 {
            ShowcaseForRideType(forView: viewTwo, Type: 1, Title: "Please scroll right or left and select center icon for Vehicle Category", ButtonTitle: "NEXT", Tag: 1)
        }
        else if number == 1 {
            ShowcaseForRideType(forView: viewThree, Type: 1, Title: "Please scroll right or left and select center icon for Pickup Address", ButtonTitle: "NEXT", Tag: 2)
        }
        else if number == 2 {
            ShowcaseForRideType(forView: refreshBtn, Type: 0, Title: "Please Click on icon to Refresh all details", ButtonTitle: "DONE", Tag: 3)
        }
        else if number == 3 {
            print("Completeddddddd")
        }
    }
    
    func ShowTripTypeShowcase() {
        ShowcaseForRideType(forView: viewOne, Type: 1, Title: "Please scroll right or left and select center icon for Trip Type", ButtonTitle: "NEXT", Tag: 0)
    }
    
    func ShowcaseForRideType(forView:UIView,Type:Int,Title:String,ButtonTitle:String,Tag:Int) {
        
        let showview = iShowcase()
        showview.delegate = self
        showview.setupShowcaseForView(forView)
        showview.type = iShowcase.TYPE(rawValue: Type)
        showview.titleLabel.text = Title
        showview.detailsLabel.text = ButtonTitle
        //        showview.coverColor = UtilitiesClassSub.color(fromHexString: "#dd335075")
        showview.coverColor = UIColor.black
        showview.highlightColor = UIColor.clear
        showview.radius = 32
        showview.Number = Tag
        showview.show()
    }
}
