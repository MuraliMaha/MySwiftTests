//
//  Constants.swift
//  BasicWithAlamoFire
//
//  Created by SunTelematics on 04/10/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit
struct WebServicesUrl {
    
    static let DriveBookingBase = "https://www.drivee.in/BookingApp/bookingservice.svc"
    static let DummySecurity = "A5F0E074-2A1E-4C39-84C4-0E28296BC54D"
    
}
