//
//  IntExtension.swift
//  BasicWithAlamoFire
//
//  Created by SunTelematics on 04/10/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit

extension Int {
    func FetchError() -> ResponceCodes {
        switch self {
        case 200:
            return .success
        case 401:
            return .authError
        case 400:
            return .badRequest
        case 408:
            return .requestTimeOut
        case 500:
            return .internalServerError
        case 503:
            return .serviceUnavailable
        case 404:
            return .notFound
        case 403:
            return .forbidden
        case 007:
            return .NoInternet
        default:
            return .OtherError
        }
    }
}
