//
//  WebService.swift
//  BasicWithAlamoFire
//
//  Created by SunTelematics on 04/10/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit
import Alamofire

class WebService {
    
    
    func callDriveBookingAPI(Suffix:String,parameterDict: [String:String], securityKey:String, completion: @escaping (_ Data:(Any),_ Responcecode:ResponceCodes,_ IsSuccess:Bool) -> ()) {
        
        let theUrlString = WebServicesUrl.DriveBookingBase + "/" + Suffix
        let theURL = URL(string: theUrlString)
        
        var mutableR = URLRequest.init(url: theURL!)
        mutableR.httpMethod = "POST"
        mutableR.allHTTPHeaderFields = ["Content-Type":"application/json","AuthenticationToken":securityKey]
        print("AuthenticationToken = ",securityKey)
        
        let ParamsData = try? JSONSerialization.data(withJSONObject: parameterDict, options: .prettyPrinted)
        
        if (ParamsData != nil) {
            mutableR.httpBody = ParamsData!
        }
        else {
            completion([:],ResponceCodes.OtherError,false)
            return
        }
        
        
        if !(Alamofire.NetworkReachabilityManager()?.isReachable)! {
            completion([:],ResponceCodes.NoInternet,false)
            return
        }
        
        mutableR.timeoutInterval = 35
        mutableR.allowsCellularAccess = true
        
        Alamofire.request(mutableR)
            .responseJSON { (DataResponce) in
                //                print(DataResponce)
                
                switch DataResponce.result {
                case .success(let value):
                    
                    completion(value,ResponceCodes.success,true)
                    
                    break
                case .failure(let error):
                    print(error.localizedDescription)
                    var responcecode = ResponceCodes.OtherError
                    if ((DataResponce.response?.statusCode) != nil) {
                        responcecode = (DataResponce.response?.statusCode)!.FetchError()
                    }
                    completion([:],responcecode,false)
                    break
                }
        }
        
    }
    
}
