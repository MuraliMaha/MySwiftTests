//
//  ViewController.swift
//  CollectionViewWithPageControlTest
//
//  Created by SunTelematics on 02/11/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireImage


class ViewController: UIViewController {

    //myCollectionView
    @IBOutlet weak var myCollectionView: UICollectionView!
    var OfferImagesarray = [[String:String]]()
    
    
    
    //VehCategoryCollectionView
    @IBOutlet weak var VehCategoryCollection: UICollectionView!
    var VehicleDataArr = [VehCategoryStruct]()
    
    
    //ConfirmCollectionView
    @IBOutlet weak var ConfirmBookingHolderView: UIView!
    @IBOutlet weak var ConfirmBookingCollection: UICollectionView!
    var ConfirmationArr = [ConfirmationStruct]()
    var SelectedVehicleStructure = VehCategoryStruct()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //myCollectionView
        myCollectionView.delegate = self
        myCollectionView.dataSource = self
        
//        var imgDict = [String:String]()
        let offerDict1 = ["ImageURL":"http://aamchidrivebooking.in/offers/offer4.png"]
        let offerDict2 = ["ImageURL":"http://aamchidrivebooking.in/offers/offer5.png"]
        let offerDict3 = ["ImageURL":"http://aamchidrivebooking.in/Images/Airport.png"]
        
        OfferImagesarray.append(offerDict1)
        OfferImagesarray.append(offerDict2)
        OfferImagesarray.append(offerDict3)
        

        //VehCategoryCollectionView
        addDataToVehicleDataArr()
        VehCategoryCollection.delegate = self
        VehCategoryCollection.dataSource = self
        
        //ConfirmCollectionView
        ConfirmBookingCollection.delegate = self
        ConfirmBookingCollection.dataSource = self
        ConfirmationMake()
        
    }

    func ConfirmationMake(){
        ConfirmationArr.removeAll()
        
//        var Con1 = ConfirmationStruct()
//        Con1.Title = "Mobikwik"
//        Con1.Image = #imageLiteral(resourceName: "MobikwikIcon")
////        Con1.PaymentType = "MOBIKWIK"
////        Con1.WalletAmount = "0"
//        Con1.showLabel = ""
//        ConfirmationArr.append(Con1)
        
        var Con1 = ConfirmationStruct()
        Con1.Title = "Cash"
        Con1.Image = #imageLiteral(resourceName: "cashinhand")
//        Con1.PaymentType = "CASH"
//        Con1.WalletAmount = "0"
        ConfirmationArr.append(Con1)
        
        var Con2 = ConfirmationStruct()
        Con2.Title = "Fare\nEstimation"
        Con2.Image = #imageLiteral(resourceName: "fareestimate")
        Con2.showLabel = ""
        
        var Con3 = ConfirmationStruct()
        Con3.Title = "Apply\nCoupon"
        Con3.Image = #imageLiteral(resourceName: "applycoupon")
        Con3.showLabel = ""
        
        
        ConfirmationArr.append(Con2)
        ConfirmationArr.append(Con3)
        
    }
    
    func addDataToVehicleDataArr() {
        
        
        
        var arr = [VehCategoryStruct]()
        

        var struct1 = VehCategoryStruct()
        struct1.CategoryName = "AC"
        struct1.CategoryImageUrl = "http://aamchidrivebooking.in/Images/AC_DASHBOARDNEW.png"
        struct1.CategoryTime = "No cabs"
        struct1.CatSelectedState = true
        self.SelectedVehicleStructure = struct1
        arr.append(struct1)
        
        var struct2 = VehCategoryStruct()
        struct2.CategoryName = "NON-AC"
        struct2.CategoryImageUrl = "http://aamchidrivebooking.in/Images/NON-AC_DASHBOARDNEW.png"
        struct2.CategoryTime = "No cabs"
        struct2.CatSelectedState = false
        arr.append(struct2)
        
        VehicleDataArr.removeAll()
        
        VehicleDataArr = arr
        print("VehicleDataArr = ",VehicleDataArr)
        
        
        
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.`
        
        
    }


}
extension ViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == myCollectionView {
                return OfferImagesarray.count
        }else if collectionView == VehCategoryCollection {
            return VehicleDataArr.count
        }else {
            return ConfirmationArr.count + 1 // +1 for placing selectedcarimage in VehConfirmCell
        }
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        if collectionView == myCollectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath)
                as! CollectionViewCellClass
            
            
            
            let urlStr = URL.init(string: "\(String(describing: self.OfferImagesarray[indexPath.row]["ImageURL"]!))" )
            print("urlStr = ",urlStr!)
            
            cell.offersImgView.af_setImage(withURL: urlStr!, placeholderImage: nil, filter: nil, progress: nil, progressQueue: DispatchQueue.main, imageTransition: .noTransition, runImageTransitionIfCached: true) { (imageData) in
                if imageData.data != nil {
                    cell.offersImgView.image = UIImage.init(data:imageData.data!)!
                }
            }
            
            cell.offersImgView.contentMode = .scaleAspectFit
            cell.offersImgView.clipsToBounds = true
            
            return cell
        }else if collectionView == VehCategoryCollection {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NewVehCategory", for: indexPath) as! NewVehCategoryCell
            print("IndexPath = ",indexPath )
            print("IndexPath.row = ",indexPath.row )
             cell.TimeLbl.text = VehicleDataArr[indexPath.row].CategoryTime!
            
            cell.TitleLbl.text = VehicleDataArr[indexPath.row].CategoryName!
           

            
            if VehicleDataArr[indexPath.row].CategoryImage != nil{
                cell.VehicleImage.image = VehicleDataArr[indexPath.row].CategoryImage
                
            }else{
                print("IndexPath.row = ",indexPath.row )

                cell.VehicleImage.af_setImage(withURL: URL.init(string: VehicleDataArr[indexPath.row].CategoryImageUrl!)!, placeholderImage: nil, filter: nil, progress: nil, progressQueue: DispatchQueue.main, imageTransition: .noTransition, runImageTransitionIfCached: true, completion: { (ImageResponce) in


                    if ImageResponce.response?.statusCode == 200{
                        if ImageResponce.data != nil {
                            let image = UIImage.init(data: ImageResponce.data!)!
                            cell.VehicleImage.image = image
                            self.VehicleDataArr[indexPath.row].CategoryImage = image
                        }
                    }
                })
            }
            if VehicleDataArr[indexPath.row].CatSelectedState! {
                cell.SelectedLbl.backgroundColor = UIColor.green
            }
            else {
                cell.SelectedLbl.backgroundColor = UIColor.clear
            }
            return cell
        }
        //ConfirmCollectionView - VehConfirmCell
        else{
            if indexPath.row == 0 {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "VehConfirm", for: indexPath) as! VehConfirmCell
                
                if SelectedVehicleStructure.CategoryImage != nil {
                    cell.VehicleImage.image = SelectedVehicleStructure.CategoryImage
                }else{
                    //                cell.VehicleImage.ImageLoaderStart()
                    cell.VehicleImage.af_setImage(withURL: URL.init(string: SelectedVehicleStructure.CategoryImageUrl!)!, placeholderImage: nil, filter: nil, progress: nil, progressQueue: DispatchQueue.main, imageTransition: .noTransition, runImageTransitionIfCached: true, completion: { (ImageResponce) in
                        //                    cell.VehicleImage.ImageLoaderStop()
                        if ImageResponce.response?.statusCode == 200{
                            if ImageResponce.data != nil {
                                let image = UIImage.init(data: ImageResponce.data!)!
                                cell.VehicleImage.image = image
                                self.SelectedVehicleStructure.CategoryImage = image
                            }
                        }
                    })
                }

    
                cell.TimeLbl.text = SelectedVehicleStructure.CategoryTime!
                cell.TitleLbl.text = SelectedVehicleStructure.CategoryName!
                
                return cell
            }
            //ConfirmCollectionView - BookConfirmCell's
            else{
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BookConfirm", for: indexPath) as! BookConfirmCell
                
                cell.TitleImage.image = ConfirmationArr[indexPath.row-1].Image
                cell.Title.text = ConfirmationArr[indexPath.row-1].Title!
                cell.fareEstimationLbl.isHidden = true
                return cell
            }
            
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
    
        if collectionView == myCollectionView {
            return CGSize(width: self.myCollectionView.frame.width, height: self.myCollectionView.frame.height)
        }else if collectionView == VehCategoryCollection {
            return CGSize.init(width: (VehCategoryCollection.frame.width / 2) - 1, height: VehCategoryCollection.frame.height)
        }else {
            
            print("Cell width = ",ConfirmBookingCollection.frame.width/4)
            return CGSize.init(width: ConfirmBookingCollection.frame.width/4, height: ConfirmBookingCollection.frame.height)
        }
        
      
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        
        
        if collectionView == myCollectionView {
            return 10
        }else if collectionView == VehCategoryCollection {
            return 1
        }else {
            return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == VehCategoryCollection {
            
            if !VehicleDataArr[indexPath.row].CatSelectedState {
                
                for i in 0..<VehicleDataArr.count {
                    
                    if indexPath.row == i {
                        VehicleDataArr[i].CatSelectedState = true
                        self.SelectedVehicleStructure = VehicleDataArr[i]
                    }
                    else {
                        VehicleDataArr[i].CatSelectedState = false
                    }
                    
                }
                
                collectionView.reloadData()
                ConfirmBookingCollection.reloadData()
            }
        }
    }
    
}
class CollectionViewCellClass : UICollectionViewCell {
    
    @IBOutlet weak var offersImgView: UIImageView!
}
//VehCategoryCollectionView
class NewVehCategoryCell: UICollectionViewCell {
    
    @IBOutlet var TimeLbl: UILabel!
    @IBOutlet var TitleLbl: UILabel!
    @IBOutlet var VehicleImage: UIImageView!
    @IBOutlet var SelectedLbl: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
struct VehCategoryStruct {
    var CategoryImage:UIImage!
    var CategoryName:String!
    var CategoryImageUrl:String!
    var CategoryTime:String!
    var CatSelectedState:Bool!
    var CategorySelectedImage:UIImage!
    var CategorySelectedurl:String!
    
}
 //ConfirmCollectionView
class VehConfirmCell: UICollectionViewCell {
    
    @IBOutlet var TimeLbl: UILabel!
    @IBOutlet var TitleLbl: UILabel!
    @IBOutlet var VehicleImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
class BookConfirmCell: UICollectionViewCell {
    
    @IBOutlet var Title: UILabel!
    @IBOutlet var TitleImage: UIImageView!
    
    @IBOutlet weak var fareEstimationLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
struct ConfirmationStruct {
    
    var Title:String!
    var Image:UIImage!
    
    
    var showLabel:String!
}
