//
//  ViewController.swift
//  MBProgressViewTest2
//
//  Created by SunTelematics on 18/09/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var Timerrrr = Timer()
    @IBOutlet weak var Progress: MBCircularProgressBarView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        
//        Timerrrr = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(CountAdd), userInfo: nil, repeats: true)
    }

    override func viewWillAppear(_ animated: Bool) {
        
    }
//    func startProgressing(){
//
//        for _ in 0...Int(Progress.maxValue) {
//            [UIView .animate(withDuration: 90, animations: {
//
//                if self.Progress.value == self.Progress.maxValue {
//                    print("Max value Reached")
//                }else{
//                    print("self.Progress.value = ",self.Progress.value)
//                    self.Progress.value = self.Progress.value + 1
//                }
//            })];
//        }
//
//    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func startBtnTapped(_ sender: UIButton) {

//
//        [UIView .animate(withDuration: 1, animations: {
//
//            if self.Progress.value == self.Progress.maxValue {
//                print("Max value Reached")
//            }else{
//                self.Progress.value = self.Progress.value + 1
//            }
//        })];

    
//        startProgressing()
        
        Timerrrr = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(CountAdd), userInfo: nil, repeats: true)
    }

    @IBAction func stopBtnTapped(_ sender: UIButton) {
    
        [UIView .animate(withDuration: 1, animations: {
            self.Progress.value = 0
        })]
        
    }
    
    func CountAdd() {
        Progress.value = Progress.value + 1
        if Progress.value == Progress.maxValue {
            Timerrrr.invalidate()
            print("Timer Invalidated")
        }
    }
}

