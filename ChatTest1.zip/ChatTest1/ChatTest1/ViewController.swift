//
//  ViewController.swift
//  ChatTest1
//
//  Created by SunTelematics on 26/12/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var receiveBtn : UIButton!
    @IBOutlet var sendBtn :  UIButton!
    @IBOutlet var msgTextField : UITextField!
    @IBOutlet var myTV : UITableView!
 
    var chatMsgArr = [(String,Bool)]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        myTV.dataSource = self
        myTV.delegate = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func sendBtnTapped(_ sender:UIButton){
        
        chatMsgArr.append((msgTextField.text!,true))
        msgTextField.text  = ""
        myTV.reloadData()
    }
    @IBAction func receiveBtnTapped(_ sender:UIButton){

        chatMsgArr.append((msgTextField.text!,false))
        msgTextField.text  = ""
        myTV.reloadData()
    }

}
extension ViewController : UITableViewDelegate ,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return chatMsgArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if chatMsgArr[indexPath.row].1{
                let cell = tableView.dequeueReusableCell(withIdentifier: "SendCellID", for: indexPath) as! SendCellClass
            cell.sendMsgLabel.text = chatMsgArr[indexPath.row].0
                return cell
        }else{
                let cell = tableView.dequeueReusableCell(withIdentifier: "ReceiveCellID", for: indexPath) as! ReceiveCellClass
                cell.receiveMsgLabel.text = chatMsgArr[indexPath.row].0
                return cell
        }
        
    }
}
class ReceiveCellClass:UITableViewCell{
    @IBOutlet var receiveMsgLabel : UILabel!
}
class SendCellClass: UITableViewCell {
    @IBOutlet var sendMsgLabel : UILabel!
}

