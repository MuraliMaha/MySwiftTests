//
//  Constants.swift
//  ShlokSqlite
//
//  Created by SunTelematics on 11/04/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit

struct NameForTable{
    static let empMaster = "EmpMaster"
    static let loginDetail = "LoginDetail"
}
struct EmpMasterTB {
    static let field_username = "username"
    static let field_password = "password"
}

struct LoginDetailTB {
    static let field_username = "username"
    static let field_password = "password"
    static let field_empcode = "empcode"
    static let field_isloginDone = "islogindone"
}
struct UserStruct {
    var username : String!
    var password : String!
}
