//
//  HomeVC.swift
//  ShlokSqlite
//
//  Created by SunTelematics on 09/04/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import FMDB

class HomeVC: UIViewController {

    var dbReference : FMDatabase!
    
    @IBOutlet weak var loggedinAsLbl: UILabel!
    
    @IBOutlet weak var myTV: UITableView!
    var usersArr = [UserStruct]()
    
    var loggedInUser : String!
    
    var success = false
    
    @IBOutlet weak var passwordToUpdateTxtField: UITextField!
    @IBOutlet weak var userToDeleteTxtField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        passwordToUpdateTxtField.delegate = self
        userToDeleteTxtField.delegate = self
        
        dbReference = FMDatabase(path: RMKDBManager.shared.pathToDatabase)
        
        loggedInUser = fetchUsersFromLoginDetailTB()
        if loggedInUser != nil{
            self.loggedinAsLbl.text = "Logged in as :" + loggedInUser
        }
        
        
        myTV.delegate = self
        myTV.dataSource = self
        
        usersArr = fetchUsersFromEmpMasterTB()
        myTV.reloadData()
    }
    func fetchUsersFromLoginDetailTB() -> String{
        if dbReference.open() {
            let query = "select * from LoginDetail"
            print("Sql =", query)
            do{
                let result = try dbReference.executeQuery(query, values: nil)
                if result.next() == true {
                    return result.string(forColumn: "username")!
                }
            }catch{
                print(error.localizedDescription)
            }
          dbReference.close()
        }else{
            print("Couldn't able to open DB")
        }
        
        return ""
    }
    
    func fetchUsersFromEmpMasterTB() -> [UserStruct] {
        if dbReference.open() {
            let query = "select * from EmpMaster"
            print("Sql =", query)
            
            usersArr.removeAll()
            do {
                let result = try dbReference.executeQuery(query, values: nil)
                while result.next() {
                    var aUserStruct = UserStruct()
                    aUserStruct.username = result.string(forColumn: "username")
                    aUserStruct.password = result.string(forColumn: "password")
                    
                    
                    
                    usersArr.append(aUserStruct)
                }
                return usersArr
                
                
                
            } catch  {
                print(error.localizedDescription)
            }
            dbReference.close()
        }else{
            print("Couldn't able to open DB")
        }
        
        return usersArr
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func logoutBtnTapped(_ sender: UIButton) {
        
        if logoutFun(){
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "LoginVCSBID") as! LoginVC
            self.present(ctrl, animated: true, completion: nil)
        }else{
            print("Couln't able to Logout")
        }
    }
    
    func logoutFun() -> Bool {
        var isDeleted = false
        
        if dbReference.open() {
            let queryDeleteAll = "delete FROM LoginDetail"
            print("Sql =", queryDeleteAll)
            
            do {
                try dbReference.executeUpdate(queryDeleteAll, values: nil)
                isDeleted = true
                print("logged out success")
            }
            catch {
                print(error.localizedDescription)
            }
            dbReference.close()
        }else{
            print("Couldn't able to open DB")
        }
        
        return isDeleted
    }
    @IBAction func updatePasswordTapped(_ sender: UIButton) {
        if passwordToUpdateTxtField.text != "" {
            
            fetchEmpMasterTBAndcheckUserAndUpdatePwd(username: loggedInUser, pwd: self.passwordToUpdateTxtField.text!)
        }
    }
    
    func fetchEmpMasterTBAndcheckUserAndUpdatePwd(username:String,pwd:String) {
        if dbReference.open() {
            //need to check whether user exists or not before updating.Here as we are updating for logged in user(existing),it is not neccessary to check user existance
            let query = "update EmpMaster set  \(EmpMasterTB.field_password)=? where \(EmpMasterTB.field_username)=?"
            print("Sql =", query)
            
            do {
                try dbReference.executeUpdate(query, values: [pwd,username])
            }
            catch {
                print(error.localizedDescription)
            }
            
            dbReference.close()
            usersArr = fetchUsersFromEmpMasterTB()
            myTV.reloadData()
            
        }else{
            print("Couldn't able to open DB")
        }
    }
    
    @IBAction func deleteBtnTapped(_ sender: UIButton) {
        
        guard self.userToDeleteTxtField.text! != loggedInUser else {
            print("cant delete loggin user")
            return
        }
        
        if dbReference.open() {
            //first check user exists or not before deleting
            let selectQuery = "select * from EmpMaster where \(EmpMasterTB.field_username) = ?"
            print(selectQuery)
            do{
                let result = try dbReference.executeQuery(selectQuery, values: ["\(self.userToDeleteTxtField.text!)"])
                if result.next() == true {
                    deleteTheUser()
                    dbReference.close()
                    usersArr = fetchUsersFromEmpMasterTB()
                    myTV.reloadData()
                }else{
                    print("Userr not exists")
                    dbReference.close()
                }
            }catch{
                dbReference.close()
                print(error.localizedDescription)
            }
            
            
            
            
        }else{
            print("Couldn't able to open DB")
        }
    }
    func deleteTheUser(){
        let query = "delete from EmpMaster where \(EmpMasterTB.field_username)='\(self.userToDeleteTxtField.text!)'"
        print("Sql =", query)
        
        do {
            try dbReference.executeUpdate(query, values: nil)
            print("Deleted Success")
        }
        catch {
            
            print(error.localizedDescription)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension HomeVC : UITableViewDataSource , UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return usersArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellID", for: indexPath) as! CellClass
        cell.userLbl.text = usersArr[indexPath.row].username
        cell.pwdLbl.text = usersArr[indexPath.row].password
        return cell
    }
    
    
}
class CellClass : UITableViewCell{
    
    @IBOutlet weak var userLbl: UILabel!
    @IBOutlet weak var pwdLbl: UILabel!
}
extension HomeVC : UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.resignFirstResponder()
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
}
