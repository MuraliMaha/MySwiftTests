//
//  ViewController.swift
//  ShlokSqlite
//
//  Created by SunTelematics on 09/04/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import FMDB

class SplashVC: UIViewController {

    var dbReference : FMDatabase!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dbReference = FMDatabase(path: RMKDBManager.shared.pathToDatabase)
        self.perform(#selector(CheckConditions), with: nil, afterDelay: 0.3)
    }

    @objc func CheckConditions(){
 
        if IsLoginAvailable() {
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HomeVCSBID") as! HomeVC
            self.present(ctrl, animated: true, completion: nil)
        }else{
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "LoginVCSBID") as! LoginVC
            self.present(ctrl, animated: true, completion: nil)
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }


    func IsLoginAvailable() -> Bool {
        
        if RMKDBManager.shared.openTheDatabase(){
            print("Test")
        }else{
            print("Test else")
        }
        
        if dbReference.open() {
            let queryCount = "select * from LoginDetail"
            print("Sql =", queryCount)
            
            do {
                let result = try dbReference.executeQuery(queryCount, values: nil)
                if result.next() == true {
                    return true
                }else{
                    print("No Row")
                    return false
                }
            }
            catch {
                print(error.localizedDescription)
            }
            dbReference.close()
        }else{
            print("Couldn't able to open DB")
            
        }
        return false
    }
}

