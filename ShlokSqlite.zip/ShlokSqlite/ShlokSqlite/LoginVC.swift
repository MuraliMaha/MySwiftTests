//
//  LoginVC.swift
//  ShlokSqlite
//
//  Created by SunTelematics on 09/04/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import FMDB

class LoginVC: UIViewController {

    @IBOutlet weak var userNameTxtField: UITextField!
    @IBOutlet weak var passwordTxtField: UITextField!
    
    var dbRef : FMDatabase!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        dbRef = FMDatabase(path: RMKDBManager.shared.pathToDatabase)
        
        userNameTxtField.delegate = self
        passwordTxtField.delegate = self
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    
    }
    
    @IBAction func loginBtnTapped(_ sender: UIButton) {
        
        
        
        if dbRef.open() {
            let querySQL = "SELECT * FROM EmpMaster WHERE \(EmpMasterTB.field_username) = '\(userNameTxtField.text!)' AND \(EmpMasterTB.field_password) = '\(passwordTxtField.text!)'"
            print("Sql =", querySQL)
            
            do {
                let result = try dbRef.executeQuery(querySQL, values: nil)
                if result.next() == true {
                    print("Login Success")
                    
                    callaFuncToSaveInLoginTB(uName: "\(self.userNameTxtField.text!)", pwd: "\(self.passwordTxtField.text!)")
                    
                    let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HomeVCSBID") as! HomeVC
                    self.present(ctrl, animated: true, completion: nil)
                    
                }else{
                    print("Login Fail")
                }
                
                
            } catch  {
                print(error.localizedDescription)
            }
        }else{
            print("Couldn't able to open DB")
        }
    }
    
    func callaFuncToSaveInLoginTB(uName : String , pwd : String){
        
//        let loggedInFlag = true
        
        let insertQuery = "insert into LoginDetail(\(LoginDetailTB.field_username),\(LoginDetailTB.field_password))values('\(self.userNameTxtField.text!)','\(self.passwordTxtField.text!)')"
        print("insert sql****\(insertQuery)")
        
        if !dbRef.executeStatements(insertQuery) {
            print("Failed to insert data into the database.")
            print(dbRef.lastError(), dbRef.lastErrorMessage())
        }else{
            print("inserted in LoginDetail success")
        }
    }
    
    @IBAction func signupBtnTapped(_ sender: UIButton) {
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "RegisterVCSBID") as! RegisterVC
        self.present(ctrl, animated: true, completion: nil)
    }
}
extension LoginVC : UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.resignFirstResponder()
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
}
