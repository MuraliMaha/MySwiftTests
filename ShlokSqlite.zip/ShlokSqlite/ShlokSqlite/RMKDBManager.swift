//
//  RMKDBManager.swift
//  ShlokSqlite
//
//  Created by SunTelematics on 09/04/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import FMDB

class RMKDBManager: NSObject {
    
    static let shared: RMKDBManager = RMKDBManager()
    
    let databaseFileName = "rmkDatabase.sqlite"
    var pathToDatabase: String! // pathToDatabase is important as this var is required to access the database from other ViewControllers
    var database: FMDatabase!

    
    
    override init() {
        super.init()
        
        let documentsDirectory = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString) as String
        pathToDatabase = documentsDirectory.appending("/\(databaseFileName)")
    }

    func createDB() -> Bool{
        if !FileManager.default.fileExists(atPath: pathToDatabase) {
            database = FMDatabase(path: pathToDatabase!)
            
            return true
        }else{
            //            print("DB Created already")
            return false
        }
    }
    
   
    
    func createTablesForMyProject(){

        let empMasterTableQuery = "create table \(NameForTable.empMaster) (\(EmpMasterTB.field_username) text,\(EmpMasterTB.field_password) text)"
        
        let loginTableQuery = "create table \(NameForTable.loginDetail) (\(LoginDetailTB.field_username) text , \(LoginDetailTB.field_password) text ,\(LoginDetailTB.field_empcode) integer,\(LoginDetailTB.field_isloginDone) bool not null default 0 )"
        
        createTable(tableName: empMasterTableQuery)
        createTable(tableName: loginTableQuery)

    }
    
    func createTable(tableName : String) {
        if openTheDatabase() {
            do{
                try database.executeUpdate(tableName, values: nil)
                
            }catch{
                print("Table \(tableName) Not Created")
                print(error.localizedDescription)
                
            }
            database.close()
        }else{
            print("Counldnt able to open DB when callling createTable")
        }
        
    }
    func openTheDatabase() -> Bool {
        if database != nil {
            if database.open() {
                return true
            }
        }
        return false
    }
}
