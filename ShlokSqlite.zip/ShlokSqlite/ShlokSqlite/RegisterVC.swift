//
//  RegisterVC.swift
//  ShlokSqlite
//
//  Created by SunTelematics on 09/04/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import  FMDB

class RegisterVC: UIViewController {

    @IBOutlet weak var userNameTxtField: UITextField!
    @IBOutlet weak var passwordTxtField: UITextField!
    
    let field_userName = "username"
    let field_password = "password"
    
    var myDBRef: FMDatabase!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        userNameTxtField.delegate = self
        passwordTxtField.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func registerBtnTapped(_ sender: UIButton) {
       
        
        
        
//        database = RMKDBManager.shared.getTheDB()
//        if RMKDBManager.shared.openTheDatabase() {
//            insertUser()
//            self.dismiss(animated: true, completion: nil)
//        }else{
//            print("Counldnt able to open DB")
//        }
        
        
        insertUser()
        
    }
    
    func insertUser() {
        
        
        myDBRef = FMDatabase(path: RMKDBManager.shared.pathToDatabase)
        if myDBRef.open(){
            
            let insertSQL = "insert into EmpMaster(\(EmpMasterTB.field_username),\(EmpMasterTB.field_password)) values('\(self.userNameTxtField.text!)','\(self.passwordTxtField.text!)')"
            print("insert sql****\(insertSQL)")
            
            if !myDBRef.executeStatements(insertSQL) {
                print("Failed to insert initial data into the database.")
                print(myDBRef.lastError(), myDBRef.lastErrorMessage())
            }else{
                print("inserted success")
                self.dismiss(animated: true, completion: nil)
            }
            
            myDBRef.close()
        }else{
            print("DB couldnot able to open")
        }
        
        
        
        
        
    }
  

}
extension RegisterVC : UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.resignFirstResponder()
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
}
