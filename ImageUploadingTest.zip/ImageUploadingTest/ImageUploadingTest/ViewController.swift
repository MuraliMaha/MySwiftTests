
//
//  ViewController.swift
//  ImageUploadingTest
//
//  Created by SunTelematics on 12/07/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myImageView: UIImageView!
    let imgPicker = UIImagePickerController()
    var imageNameIS : String!

    override func viewDidLoad() {
        super.viewDidLoad()

         self.imgPicker.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func myBtnTapped(_ sender: UIButton) {
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            imgPicker.allowsEditing = false
            imgPicker.sourceType = UIImagePickerControllerSourceType.camera
            imgPicker.cameraCaptureMode = .photo
            imgPicker.modalPresentationStyle = .fullScreen
            present(imgPicker, animated: true, completion: nil)
        }else{
            print("No Camera")
        }

    }

}

extension ViewController : UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        var  chosenImage = UIImage()
        chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage //2
        myImageView.contentMode = .scaleAspectFit //3
        myImageView.image = chosenImage //4
        
        callProfileWebService(selectedImg: chosenImage)
       
        dismiss(animated:true, completion: nil) //5
    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func callProfileWebService(selectedImg : UIImage){
        let todatDate = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = "yyyyMMdd_HHmmss"
        let dateConverted: String = dateFormatter.string(from: todatDate)
        imageNameIS = "VEN_007\(dateConverted).\((UIImagePNGRepresentation(selectedImg) != nil) ? "png" : "jpg")"
        print("Image Name = \(imageNameIS!)")
        
        
        
        uploadImage(selImage: selectedImg)
    }
    func uploadImage(selImage : UIImage) {
        let request: URLRequest
        
        do {
            request = createRequest(selecImage: selImage)
        } catch {
            print(error)
            return
        }
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard error == nil else {
                // handle error here
                print(error!)
                return
            }
            
            // if response was JSON, then parse it
            
            do {
                let responseDictionary = try JSONSerialization.jsonObject(with: data!)
                print("success == \(responseDictionary)")
                
                // note, if you want to update the UI, make sure to dispatch that to the main queue, e.g.:
                //
                // DispatchQueue.main.async {
                //     // update your UI and model objects here
                // }
            } catch {
                print(error)
                
                let responseString = String(data: data!, encoding: .utf8)
                print("responseString = \(responseString)")
            }
        }
        task.resume()
    }
    
    
    
    func createRequest(selecImage : UIImage)  -> URLRequest {
        let parameters = [
            "seleectedImageName"  : imageNameIS]  // build your dictionary however appropriate
        
        let boundary = generateBoundaryString()
        
        let url = URL(string: "http://drivee.in/DriveDriverApp/ImageuploadAll.aspx")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
//        let path1 = Bundle.main.path(forResource: "image1", ofType: "png")!
        
        let imageData = (UIImagePNGRepresentation(selecImage) != nil) ? UIImagePNGRepresentation(selecImage) : UIImageJPEGRepresentation(selecImage,0)
        
//        if(imageData==nil)  { return  }

//        request.httpBody = try createBody(with: parameters, filePathKey: "uploaded_file", imageDataKey : imageData, boundary: boundary)
        
        request.httpBody =  createBody(with: parameters as! [String : String], filePathKey: "uploaded_file", imageDataKey: imageData!, boundary: boundary)
        return request
    }

    func createBody(with parameters: [String: String]?, filePathKey: String,imageDataKey : Data, boundary: String)  -> Data {
        var body = Data()
        
        if parameters != nil {
            for (key, value) in parameters! {
                body.append("--\(boundary)\r\n")
                body.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n")
                body.append("\(value)\r\n")
            }
        }
        
        body.append("--\(boundary)\r\n")
        body.append("Content-Disposition: form-data; name=\"\(filePathKey)\"; filename=\"\(imageNameIS)\"\r\n")
//        body.append("Content-Type: \(mimetype)\r\n\r\n")
//        body.append("Content-Type: application/octet-stream\r\n\r\n")
        body.append("Content-Type: application/octet-stream\r\n\r\n")
        body.append(imageDataKey)
        body.append("\r\n")

        body.append("--\(boundary)--\r\n")
        return body
    }
    func generateBoundaryString() -> String {
        return "Boundary-\(NSUUID().uuidString)"
    }

    
    
    
    
    
//    func uploadImage(selImage : UIImage!){
//        
//        let myUrl = NSURL(string: "http://drivee.in/DriveDriverApp/ImageuploadAll.aspx");
//     
//        
//        let request = NSMutableURLRequest(url:myUrl! as URL);
////        var request = URLRequest.init(url: URL.init(string: "http://drivee.in/DriveDriverApp/ImageuploadAll.aspx")!);
//
//        request.httpMethod = "POST";
//        
//        let param = [
//            "firstName"  : "Sergey",
//            "lastName"    : "Kargopolov",
//            "userId"    : "9"
//        ]
//        
//        let boundary = generateBoundaryString()
//        
//        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
//        
//        
//        let imageData = UIImageJPEGRepresentation(selImage!, 1)
//        
//        if(imageData==nil)  { return; }
//        
//        request.httpBody = createBodyWithParameters(parameters: param, filePathKey: "uploaded_file", imageDataKey: imageData! as NSData, boundary: boundary) as Data
//        
//     
//        let task = URLSession.shared.dataTask(with: request as URLRequest) {
//            data, response, error in
//            
//            if error != nil {
//                print("error=\(error)")
//                return
//            }
//            
//            // You can print out response object
//            print("******* response = \(response)")
//            
//            // Print out reponse body
//            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
//            print("****** response data = \(responseString!)")
//            
//            do {
//                let json = try JSONSerialization.jsonObject(with: data!, options: []) as? NSDictionary
//                
//                print(json)
//                
//               
//                
//            }catch
//            {
//                print(error)
//            }
//            
//        }
//        
//        task.resume()
//
//    }
//    func createBodyWithParameters(parameters: [String: String]?, filePathKey: String?, imageDataKey: NSData, boundary: String) -> NSData {
//        let body = NSMutableData();
//        
//        if parameters != nil {
//            for (key, value) in parameters! {
//                body.appendString(string: "--\(boundary)\r\n")
//                body.appendString(string: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n")
//                body.appendString(string: "\(value)\r\n")
//            }
//        }
//        
////        let filename = "user-profile.jpg"
//        let filename = imageNameIS
////        let mimetype = "image/jpg"
//        
//        body.appendString(string: "--\(boundary)\r\n")
//        body.appendString(string: "Content-Disposition: form-data; name=\"\(filePathKey!)\"; filename=\"\(filename)\"\r\n")
////        body.appendString(string: "Content-Type: \(mimetype)\r\n\r\n")
//        body.appendString(string: "Content-Type: application/octet-stream\r\n\r\n")
//        body.append(imageDataKey as Data)
//        body.appendString(string: "\r\n")
//        
//        
//        
//        body.appendString(string: "--\(boundary)--\r\n")
//        
//        return body
//    }
//    
//    
//    
//    func generateBoundaryString() -> String {
//        return "Boundary-\(NSUUID().uuidString)"
//    }
    
    
    
    
    
    
//    func uploadImage(selImage : UIImage){
//
//        let request: URLRequest
//        
//        do {
//
//            request = try createRequest(filename: imageNameIS, selectedImage: selImage)
//        } catch {
//            print(error)
//            return
//        }
//        
//        let task = URLSession.shared.dataTask(with: request) { data, response, error in
//            guard error == nil else {
//                // handle error here
//                print(error!)
//                return
//            }
//            
//            // if response was JSON, then parse it
//            
//            do {
//                let responseDictionary = try JSONSerialization.jsonObject(with: data!)
//                print("success == \(responseDictionary)")
//                       } catch {
//                print(error)
//                
//                let responseString = String(data: data!, encoding: .utf8)
//                print("responseString = \(responseString)")
//                
//            }
//        }
//        task.resume()
//        
//    }
//    func createRequest(filename: String,selectedImage : UIImage) throws -> URLRequest {
//        let parameters = [
//            "filename"  : filename
//           ]  // build your dictionary however appropriate
//        
//        let boundary = generateBoundaryString()
//        
//        let url = URL(string: "http://drivee.in/DriveDriverApp/ImageuploadAll.aspx")!
//        var request = URLRequest(url: url)
//        request.httpMethod = "POST"
//        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
//        
////        let path1 = Bundle.main.path(forResource: "image1", ofType: "png")!
//        let imageData = (UIImagePNGRepresentation(selectedImage) != nil) ? UIImagePNGRepresentation(selectedImage) : UIImageJPEGRepresentation(selectedImage,0)
//        request.httpBody = try createBody(with: parameters, filePathKey: "uploaded_file", imageDataKey: imageData!, boundary: boundary,fileName : imageNameIS)
//        
//        return request
//    }
//    func createBody(with parameters: [String: String]?, filePathKey: String, imageDataKey:Data, boundary: String,fileName : String) throws -> Data {
//        var body = Data()
//        
//        if parameters != nil {
//            for (key, value) in parameters! {
//                body.append("--\(boundary)\r\n")
//                body.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n")
//                body.append("\(value)\r\n")
//            }
//        }
//        
////        for path in paths {
////            let url = URL(fileURLWithPath: path)
////            let filename = url.lastPathComponent
////            let data = try Data(contentsOf: url)
////            let mimetype = mimeType(for: path)
////            
////            body.append("--\(boundary)\r\n")
////            body.append("Content-Disposition: form-data; name=\"\(filePathKey)\"; filename=\"\(filename)\"\r\n")
////            body.append("Content-Type: \(mimetype)\r\n\r\n")
////            body.append(data)
////            body.append("\r\n")
////        }
////
//        body.append("--\(boundary)\r\n")
//        body.append("Content-Disposition: form-data; name=\"\(filePathKey)\"; filename=\"\(fileName)\"\r\n")
////        body.append("Content-Type: "application/octet-stream"\r\n\r\n")
//        body.append("Content-Type: application/octet-stream\r\n\r\n")
//        body.append(imageDataKey)
//        body.append("\r\n")
//        
//        
//        body.append("--\(boundary)--\r\n")
//        return body
//    }
//    func generateBoundaryString() -> String {
//        return "Boundary-\(NSUUID().uuidString)"
//    }
//    func mimeType(for path: String) -> String {
//        let url = NSURL(fileURLWithPath: path)
//        let pathExtension = url.pathExtension
//        
////        if let uti = UTTypeCreatePreferredIdentifierForTag(kUTTagClassFilenameExtension, pathExtension! as NSString, nil)?.takeRetainedValue() {
////            if let mimetype = UTTypeCopyPreferredTagWithClass(uti, kUTTagClassMIMEType)?.takeRetainedValue() {
////                return mimetype as String
////            }
////        }
//        return "application/octet-stream";
//    }
    
    
}

extension Data {
    
    /// Append string to NSMutableData
    ///
    /// Rather than littering my code with calls to `dataUsingEncoding` to convert strings to NSData, and then add that data to the NSMutableData, this wraps it in a nice convenient little extension to NSMutableData. This converts using UTF-8.
    ///
    /// - parameter string:       The string to be added to the `NSMutableData`.
    
    mutating func append(_ string: String) {
        if let data = string.data(using: .utf8) {
            append(data)
        }
    }
}
//    extension NSMutableData {
//        
//        func appendString(string: String) {
//            let data = string.data(using: String.Encoding.utf8, allowLossyConversion: true)
//            append(data!)
//        }
//    }

//extension Data {
//    
//    /// Append string to NSMutableData
//    ///
//    /// Rather than littering my code with calls to `dataUsingEncoding` to convert strings to NSData, and then add that data to the NSMutableData, this wraps it in a nice convenient little extension to NSMutableData. This converts using UTF-8.
//    ///
//    /// - parameter string:       The string to be added to the `NSMutableData`.
//    
//    mutating func append(_ string: String) {
//        if let data = string.data(using: .utf8) {
//            append(data)
//        }
//    }
//}
