//
//  ViewController.swift
//  SnapShotOfLatLng
//
//  Created by SunTelematics on 09/11/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController {

    @IBOutlet var myImageView : UIImageView!
    var PickUpCoordinates: CLLocationCoordinate2D!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myImageView.contentMode = .scaleAspectFit //myImageView size is 250*250.But we are creating snapshot of size 200 * 200.This contentmode = .scaleAspectFit fits the 200*200 image in 250*250 myImageView
        
        myImageView.clipsToBounds = true // we set corner radius to myImageView.only if we set this clipsToBounds,it will clips the image to its bounds/boundary
        
        myImageView.layer.cornerRadius = myImageView.frame.width/2

        
        
        //        11.045400, 76.802780 12.939949, 77.625732
        
        
        PickUpCoordinates  = CLLocationCoordinate2DMake(12.939949,77.625732)
        print(PickUpCoordinates)
        
        renderSnapshot(PickUpCoordinates!, CGSize.init(width: 200, height: 200),self.ReduceImageSize(UIImage.init(named:"GreenTrack")!, CGSize.init(width: 25, height: 25))){ (imageout, errorstr) in
            //
            DispatchQueue.main.async {
                if (errorstr == nil) {
                    //                    self.myImageView.layer.cornerRadius = self.myImageView.frame.width/2
                    self.myImageView.image = imageout!
                    print("Snap Image size :",imageout?.size as Any)
                    
                }
                else {
                    
                }
            }
            
        }
//        Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(loadonce), userInfo: nil, repeats: false)
        
       
    }

    override func viewDidAppear(_ animated: Bool) {
        
    }
    @objc func loadonce() {
        myImageView.layer.cornerRadius = myImageView.frame.width/2
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }



    func renderSnapshot(_ Location:CLLocationCoordinate2D,_ size:CGSize,_ OverLay:UIImage, completion: @escaping (_ image:UIImage?,_ error:String?) -> Void) {
        let MapSnapShot = MKMapSnapshotOptions()
        MapSnapShot.size = size
        MapSnapShot.scale = UIScreen.main.scale
        
        let Span = MKCoordinateSpanMake(0.01, 0.01)
        MapSnapShot.region = MKCoordinateRegionMake(Location, Span)
        
        let Snapshotter = MKMapSnapshotter.init(options: MapSnapShot)
        Snapshotter.start { (snapshot, error) in
            if (error == nil) {
                let imageBack = (snapshot?.image)!
                let MarkImage = OverLay
                
                UIGraphicsBeginImageContextWithOptions(imageBack.size, false, 0.0)
                imageBack.draw(in: CGRect.init(x: 0, y: 0, width: imageBack.size.width, height: imageBack.size.height))
                MarkImage.draw(in: CGRect.init(x: (imageBack.size.width/2) - (OverLay.size.width/2) , y: (imageBack.size.height/2) - (OverLay.size.height/2), width: OverLay.size.width, height: OverLay.size.height))
               
                
                let finalimage = UIGraphicsGetImageFromCurrentImageContext()
                UIGraphicsEndImageContext()
                completion(finalimage,nil)
            }
            else {
                completion(nil,"Error rendering snapshot for map at: (\(MapSnapShot.region.center.latitude), \(MapSnapShot.region.center.longitude)) with Error:\(String(describing: error?.localizedDescription))");
            }
        }
        
    }
    func ReduceImageSize(_ originalImg:UIImage,_ size:CGSize) -> UIImage {

        let canvasSize = CGSize.init(width: size.width , height:(size.width/originalImg.size.width) * originalImg.size.height)
        UIGraphicsBeginImageContextWithOptions(originalImg.size, false, originalImg.scale)
        originalImg.draw(in: CGRect.init(x: 0, y: 0, width: canvasSize.width, height: canvasSize.height))
        let img = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        print("www=",img?.size.width as Any, "hhh=",img?.size.height as Any)
        return img!
    }
}

