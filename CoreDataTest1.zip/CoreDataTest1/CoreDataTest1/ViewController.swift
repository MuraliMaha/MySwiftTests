//
//  ViewController.swift
//  CoreDataTest1
//
//  Created by SunTelematics on 23/11/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myTV: UITableView!
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var humansArray: [Human] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        myTV.delegate = self
        myTV.dataSource = self
        
//        self.perform(#selector(LoadData), with: nil, afterDelay: 0.15)
        self.perform(#selector(loadVC), with: nil, afterDelay: 0.2)
    }
    @objc func loadVC(){
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddNamesVCSBID") as! AddNamesVCViewController
        
//        let nav = self.navigationController
        self.present(vc, animated: true, completion: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        getData()
        myTV.reloadData()
    }
    func getData() {
        do {
            humansArray = try context.fetch(Human.fetchRequest())
        } catch {
            print("Fetching Failed")
        }
    }

}
extension ViewController : UITableViewDelegate , UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return humansArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELLID", for: indexPath) as! CellClass
        
        let hu = humansArray[indexPath.row]
        
        if let myName = hu.name {
            cell.nameLabel?.text = myName
        }
        return cell
    }
//    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
//        if UITableViewCellEditingStyle.delete {
//            let hu = humans[indexPath.row]
//            context.delete(hu)
//            (UIApplication.shared.delegate as! AppDelegate).saveContext()
//
//            do {
//                humans = try context.fetch(Human.fetchRequest())
//            } catch {
//                print("Fetching Failed")
//            }
//        }
//        myTV.reloadData()
//    }
}
class CellClass : UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
}
