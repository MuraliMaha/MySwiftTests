//
//  ViewController.swift
//  DownloadImageAsData
//
//  Created by SunTelematics on 22/11/17.
//  Copyright © 2017 SunTelematics. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myImgView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        myImgView.contentMode = .scaleAspectFit
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnTapped(_ sender: UIButton) {
        
//        if you are using HTTP connection and not https don't forget to add this
//        App Transport Security Settings as dictionary and into it  Allow Arbitrary Loads as Boolean with value YES
        
        // https://static.pexels.com/photos/34950/pexels-photo.jpg
        if let url = NSURL(string:"https://4.bp.blogspot.com/--anf7aXc5cA/WYixCyUSN0I/AAAAAAAAAIU/xdPtPxeBa0wpz19-sMv56CTCHLGVki8AACEwYBhgL/s100-c/Happy-New-Year-2018-Cartoon-Images-Wallpapers.jpg"){
            if let dataOfURL = NSData(contentsOf: url as URL){
                myImgView.image = UIImage(data: dataOfURL as Data)
            }
        }
    }
    
}

