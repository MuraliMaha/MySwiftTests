//
//  HomeVC.swift
//  Shlok
//
//  Created by SunTelematics on 04/04/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import CoreData

class HomeVC: UIViewController {

    lazy var Delegate: AppDelegate = {
        return UIApplication.shared.delegate as! AppDelegate
    }()
    @IBOutlet weak var testLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let loginTBObj = fetchLoginTB()
        self.testLbl.text = "Loged in as " + loginTBObj.username!
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func logoutTapped(_ sender: UIButton) {
        let context = Delegate.managedObjectContext
        let deleteFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "LoginTB")
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: deleteFetch)
        
        do {
            try context.execute(deleteRequest)
            try context.save()
            self.performSegue(withIdentifier: "toLoginFromHome", sender: nil)
        } catch {
            print ("There was an error deleting the table RMK")
        }
    }
   
    func fetchLoginTB() -> LoginTB {
        let context = Delegate.managedObjectContext
        let entity = NSEntityDescription.entity(forEntityName: "LoginTB", in: context)
        let request = NSFetchRequest<LoginTB>.init()
        request.entity = entity
        let arr = try? context.fetch(request)
        return arr![0]
    }

}
