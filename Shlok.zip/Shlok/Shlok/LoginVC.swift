//
//  LoginVC.swift
//  Shlok
//
//  Created by SunTelematics on 04/04/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import CoreData

class LoginVC: UIViewController {

    @IBOutlet weak var userNameTxtField: UITextField!
    @IBOutlet weak var passwordTxtField: UITextField!
    
    lazy var Delegate: AppDelegate = {
        return UIApplication.shared.delegate as! AppDelegate
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        userNameTxtField.delegate = self
        passwordTxtField.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func loginBtnTapped(_ sender: UIButton) {
        
        let uName = userNameTxtField.text
        let pwd = passwordTxtField.text
        
        let userExists = fetchEmpMasterTBAndcheckUser(username: uName!, password: pwd!)
        if userExists {
            self.performSegue(withIdentifier: "HomeVCSegID", sender: nil)
        }else{
            print("User doesnt exist")
        }
    }
    
    func fetchEmpMasterTBAndcheckUser(username:String , password:String) -> Bool {
        let context = Delegate.managedObjectContext
        let entity = NSEntityDescription.entity(forEntityName: "EmpMasterTB", in: context)
        let request = NSFetchRequest<EmpMasterTB>.init()
        request.entity = entity
        request.predicate = NSPredicate(format: "username == %@", username)
        let arr = try? context.fetch(request)
        if (arr?.count)! > 0 {
            callaFuncToSaveInLoginTB(username: username, pwd: password)
            return true
        }
        return false
    }
   
    func callaFuncToSaveInLoginTB(username : String , pwd :String){
        let loginTBObj = NSEntityDescription.insertNewObject(forEntityName: "LoginTB", into: Delegate.managedObjectContext) as! LoginTB
        loginTBObj.username = username
        loginTBObj.password = pwd
        loginTBObj.isLoginDone = true
        
        Delegate.saveContext()
    }
    
    
    @IBAction func signupBtnTapped(_ sender: UIButton) {
        self.performSegue(withIdentifier: "RegisterVCSegID", sender: nil)
    }

}
extension LoginVC : UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
        textField.resignFirstResponder()
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
}
