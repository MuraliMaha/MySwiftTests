//
//  ViewController.swift
//  Shlok
//
//  Created by SunTelematics on 04/04/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit
import CoreData

//At a time one one user can login in a mobile.So only one row in LoginTB.When logging out that row/LoginTB should be deleted.when logging in with other user one row/record should be created in LoginTB.This row specifies the details of user currently logged in.

class SplashVC: UIViewController {

    lazy var Delegate: AppDelegate = {
        return UIApplication.shared.delegate as! AppDelegate
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.perform(#selector(CheckConditions), with: nil, afterDelay: 0.3)
    }
  
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @objc func CheckConditions(){
        if IsLoginAvailable() {
            self.performSegue(withIdentifier: "HomeVCSegID", sender: nil)
        }else{
            self.performSegue(withIdentifier: "LoginVCSegID", sender: nil)
        }
        
    }
    func IsLoginAvailable() -> Bool {
        let context = Delegate.managedObjectContext
        let entity = NSEntityDescription.entity(forEntityName: "LoginTB", in: context)
        let request = NSFetchRequest<LoginTB>.init()
        request.entity = entity
        let arr = try? context.fetch(request)
        if (arr?.count)! > 0 {
            let Login = (arr?[0])!
            if Login.isLoginDone {
                return true
            }
        }
        return false
    }
}


