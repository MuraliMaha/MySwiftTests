//
//  ViewController.swift
//  UserdefaultsImageTest
//
//  Created by SunTelematics on 03/01/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var selectedImageView: UIImageView!
    var imageNameIS : String!
     var finalImage : UIImage!
    
    let imgPicker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.imgPicker.delegate = self
       // self.selectedImageView = nil
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func chooseTapped(_ sender: UIButton) {
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            imgPicker.allowsEditing = false
            imgPicker.sourceType = UIImagePickerControllerSourceType.camera
            imgPicker.cameraCaptureMode = .photo
            imgPicker.modalPresentationStyle = .fullScreen
            imgPicker.setEditing(true, animated: true)
            imgPicker.allowsEditing = true
            present(imgPicker, animated: true, completion: nil)
        }else{
            print("No Camera")
        }
    }
    
    @IBAction func GetFromLocalBtnTapped(_ sender: UIButton) {
        if UserDefaults.standard.object(forKey: "savedProfileImage") != nil{
            let profileImageData = UserDefaults.standard.object(forKey: "savedProfileImage") as! Data
            finalImage = UIImage(data: profileImageData)
            selectedImageView.contentMode = .scaleAspectFill
            selectedImageView.image = finalImage
            
        }else{
            print("There is no image file in userDefaults")
            finalImage = UIImage(named: "profileImage")
            selectedImageView.image = finalImage
        }
    }
    
    func saveProfileImageToLocal(selectedImg : UIImage){
        let todatDate = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = "yyyyMMdd_HHmmss"
        let dateConverted: String = dateFormatter.string(from: todatDate)
        
        imageNameIS = "VEN_\(dateConverted).\((UIImagePNGRepresentation(selectedImg) != nil) ? "png" : "jpg")"
        
        print("Image Name = \(imageNameIS!)")
        
        let imageData : Data = UIImageJPEGRepresentation(selectedImg, 1)!
        UserDefaults.standard.set(imageData, forKey: "savedProfileImage")
        UserDefaults.standard.set(imageNameIS, forKey: "savedProfileImageName")
        print("Profile image Written to UserDefaults")
    }
    
}
extension ViewController : UIImagePickerControllerDelegate , UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        var  chosenImage = UIImage()
        chosenImage = info[UIImagePickerControllerEditedImage] as! UIImage //2
        selectedImageView.contentMode = .scaleAspectFit //3
        selectedImageView.image = chosenImage //4
        
        saveProfileImageToLocal(selectedImg : chosenImage)
        
        dismiss(animated:true, completion: nil) //5
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}


