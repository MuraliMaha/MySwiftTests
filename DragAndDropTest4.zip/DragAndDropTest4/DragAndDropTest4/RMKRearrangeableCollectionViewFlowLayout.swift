//
//  RMKRearrangeableCollectionViewFlowLayout.swift
//  DragAndDropTest4
//
//  Created by SunTelematics on 14/03/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit


protocol RMKRearrangeableCollectionViewDelegate : UICollectionViewDelegate {
    func canMoveItem(at indexPath : IndexPath) -> Bool
    func moveDataItem(from source : IndexPath, to destination: IndexPath) -> Void
}

extension RMKRearrangeableCollectionViewDelegate {
    func canMoveItem(at indexPath : IndexPath) -> Bool {
        return true
    }
}

enum RMKDraggingAxis {
    case free
    case x
    case y
    case xy
}


class RMKRearrangeableCollectionViewFlowLayout: UICollectionViewFlowLayout {

    var animating : Bool = false
    var draggable : Bool = true
    
    var collectionViewFrameInCanvas : CGRect = CGRect.zero
    var canvas : UIView? {
        didSet {
            if canvas != nil {
                self.calculateBorders()
            }
        }
    }
    var axis : RMKDraggingAxis = .free
    
    struct Bundle {
        var offset : CGPoint = CGPoint.zero
        var sourceCell : UICollectionViewCell
        var representationImageView : UIView
        var currentIndexPath : IndexPath
    }
    var bundle : Bundle?
    
    
    override init() {
        super.init()
        self.setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.setup()
    }
    
    func setup() {
        
        if let collectionView = self.collectionView {
            
            let longPressGestureRecogniser = UILongPressGestureRecognizer(target: self, action: #selector(RMKRearrangeableCollectionViewFlowLayout.handleGesture(_:)))
            
            longPressGestureRecogniser.minimumPressDuration = 0.2
            longPressGestureRecogniser.delegate = self
            
            collectionView.addGestureRecognizer(longPressGestureRecogniser)
            
            if self.canvas == nil {
                
                self.canvas = self.collectionView!.superview
                
            }
            
            
        }
    }
    
    override func prepare() {
        super.prepare()
        //        self.calculateBorders()
    }
    
    fileprivate func calculateBorders() {
        if let collectionView = self.collectionView {
            collectionViewFrameInCanvas = collectionView.frame
        }
    }
    
}
extension RMKRearrangeableCollectionViewFlowLayout : UIGestureRecognizerDelegate {
    
    func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        
        if draggable == false {
            return false
        }
        
        guard let ca = self.canvas else {
            return false
        }
        
        guard let cv = self.collectionView else {
            return false
        }
        
        let pointPressedInCanvas = gestureRecognizer.location(in: ca)
        
        for cell in cv.visibleCells {
            
            guard let indexPath:IndexPath = cv.indexPath(for: cell) else {
                return false
            }
            
            let cellInCanvasFrame = ca.convert(cell.frame, from: cv)
            
            if cellInCanvasFrame.contains(pointPressedInCanvas ) {
                
                if cv.delegate is RMKRearrangeableCollectionViewDelegate {
                    let d = cv.delegate as! RMKRearrangeableCollectionViewDelegate
                    if d.canMoveItem(at: indexPath) == false {
                        return false
                    }
                }
                
                if let rmkCell = cell as? MyCollectionViewCellClass {
                    // Override he dragging setter to apply and change in style that you want
                    rmkCell.dragging = true
                }
                
                UIGraphicsBeginImageContextWithOptions(cell.bounds.size, cell.isOpaque, 0)
                cell.layer.render(in: UIGraphicsGetCurrentContext()!)
                let img = UIGraphicsGetImageFromCurrentImageContext()
                UIGraphicsEndImageContext()
                
                let representationImage = UIImageView(image: img)
                
                representationImage.frame = cellInCanvasFrame
                
                let offset = CGPoint(x: pointPressedInCanvas.x - cellInCanvasFrame.origin.x, y: pointPressedInCanvas.y - cellInCanvasFrame.origin.y)
                
                self.bundle = Bundle(offset: offset, sourceCell: cell, representationImageView:representationImage, currentIndexPath: indexPath)
                
                break
            }
            
        }
        
        return (self.bundle != nil)
    }
    
    @objc func handleGesture(_ gesture: UILongPressGestureRecognizer) -> Void {
        
        
        guard let bundle = self.bundle else {
            return
        }
        
        
        func endDraggingAction(_ bundle: Bundle) {
            
            bundle.sourceCell.isHidden = false
            
            if let rmkCell = bundle.sourceCell as? MyCollectionViewCellClass {
                rmkCell.dragging = false
            }
            
            bundle.representationImageView.removeFromSuperview()
            
            // if we have a proper data source then we can reload and have the data displayed correctly
            if let cv = self.collectionView, cv.delegate is RMKRearrangeableCollectionViewDelegate {
                cv.reloadData()
            }
            
            self.bundle = nil
        }
        
        let dragPointOnCanvas = gesture.location(in: self.canvas)
        
        
        switch gesture.state {
            
            
        case .began:
            
            bundle.sourceCell.isHidden = true
            self.canvas?.addSubview(bundle.representationImageView)
            
            var imageViewFrame = bundle.representationImageView.frame
            var point = CGPoint.zero
            point.x = dragPointOnCanvas.x - bundle.offset.x
            point.y = dragPointOnCanvas.y - bundle.offset.y
            
            imageViewFrame.origin = point
            bundle.representationImageView.frame = imageViewFrame
            
            break
            
        case .changed:
            // Update the representation image
            var imageViewFrame = bundle.representationImageView.frame
            var point = CGPoint(x: dragPointOnCanvas.x - bundle.offset.x, y: dragPointOnCanvas.y - bundle.offset.y)
            if self.axis == .x {
                point.y = imageViewFrame.origin.y
            }
            if self.axis == .y {
                point.x = imageViewFrame.origin.x
            }
            
            
            imageViewFrame.origin = point
            bundle.representationImageView.frame = imageViewFrame
            
            
            var dragPointOnCollectionView = gesture.location(in: self.collectionView)
            
            if self.axis == .x {
                dragPointOnCollectionView.y = bundle.representationImageView.center.y
            }
            if self.axis == .y {
                dragPointOnCollectionView.x = bundle.representationImageView.center.x
            }
            
            
            
            
            if let indexPath : IndexPath = self.collectionView?.indexPathForItem(at: dragPointOnCollectionView) {
                
                //                self.checkForDraggingAtTheEdgeAndAnimatePaging(gesture)
                
                
                if (indexPath == bundle.currentIndexPath) == false {
                    
                    // If we have a collection view controller that implements the delegate we call the method first
                    if let delegate = self.collectionView!.delegate as? RMKRearrangeableCollectionViewDelegate {
                        delegate.moveDataItem(from: bundle.currentIndexPath, to: indexPath)
                    }
                    
                    self.collectionView!.moveItem(at: bundle.currentIndexPath, to: indexPath)
                    
                    self.bundle!.currentIndexPath = indexPath
                    
                }
                
            }
            break
            
            
        case .ended:
            endDraggingAction(bundle)
            
            break
            
        case .cancelled:
            endDraggingAction(bundle)
            
            break
            
        case .failed:
            endDraggingAction(bundle)
            
            break
            
            
        case .possible:
            break
            
            
        }
        
    }

}
