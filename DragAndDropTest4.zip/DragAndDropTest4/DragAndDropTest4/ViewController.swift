//
//  ViewController.swift
//  DragAndDropTest4
//
//  Created by SunTelematics on 13/03/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myCollView: UICollectionView!
    @IBOutlet weak var flowLayoutReference: RMKRearrangeableCollectionViewFlowLayout!
    
    var myImagesArray: [(UIImage,String)] = [
        (UIImage(named: "Airport")!,"Aeroplane"),
        (UIImage(named: "test")!,"Mountain"),
        (UIImage(named: "Outstation")!,"Car"),
        (UIImage(named: "Package")!,"Tree"),
        (UIImage(named: "truckImage")!,"Truck"),
        (UIImage(named: "StarFilled")!,"Star")
    ]
    var myTitleArr : [String] = ["A","B","C","D","Active","Free"] // ,"7","8"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.myCollView.delegate = self
        self.myCollView.dataSource = self
        
        self.flowLayoutReference.draggable = true
        self.flowLayoutReference.axis = .free
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
extension ViewController :UICollectionViewDataSource ,UICollectionViewDelegateFlowLayout {
    
//    func numberOfSections(in collectionView: UICollectionView) -> Int {
//        return 1
//    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return myTitleArr.count
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = self.myCollView.dequeueReusableCell(withReuseIdentifier: "MYCELLID", for: indexPath) as! MyCollectionViewCellClass
        cell.myTitleLbl.text = self.myTitleArr[indexPath.item]
        cell.myImgView.image = self.myImagesArray[indexPath.item].0
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let totalInteritemSpacing = (1 * flowLayoutReference.minimumInteritemSpacing)
        let totalSectionInset = flowLayoutReference.sectionInset.left + flowLayoutReference.sectionInset.right
        let w = (collectionView.bounds.width - (totalSectionInset + totalInteritemSpacing)) / 2
        let h = w/1.5
        
        return CGSize(width: w, height: h)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("Selected Title is : ",myTitleArr[indexPath.row])
        print("Selected Image Name is :",myImagesArray[indexPath.row].1)
    }
}
extension ViewController : RMKRearrangeableCollectionViewDelegate {
    func canMoveItem(at indexPath: IndexPath) -> Bool {
        return true
    }
    
    func moveDataItem(from source : IndexPath, to destination: IndexPath) -> Void {
        let name = self.myTitleArr[source.item]
        self.myTitleArr.remove(at: source.item)
        self.myTitleArr.insert(name, at: destination.item)
        
        let img = self.myImagesArray[source.item]
        self.myImagesArray.remove(at: source.item)
        self.myImagesArray.insert(img, at: destination.item)
    }
}
