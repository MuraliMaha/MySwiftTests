//
//  MyCollectionViewCellClass.swift
//  DragAndDropTest4
//
//  Created by SunTelematics on 14/03/18.
//  Copyright © 2018 SunTelematics. All rights reserved.
//

import UIKit

class MyCollectionViewCellClass: UICollectionViewCell {
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    var baseBackgroundColor : UIColor?
    var dragging : Bool = false {
        
        didSet {
            
            if dragging == true {
                self.baseBackgroundColor = self.backgroundColor
                self.backgroundColor = UIColor.red
            } else {
                self.backgroundColor = self.baseBackgroundColor
            }
        }
    }
    
    
    @IBOutlet weak var myImgView: UIImageView!
    @IBOutlet weak var myTitleLbl: UILabel!
    
    
    
}
